class Scenario(): 
    def __init__(self):
        print() 